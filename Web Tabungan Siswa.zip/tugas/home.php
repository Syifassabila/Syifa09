<?php
include "session.php";
include "koneksi.php";
?>

<p align="center">

Halo,selamat datang <b> <?php echo $_SESSION['username']; ?> </b> <br>
Silahkan <a href="logout.php"> <b> Logout </b> </a>untuk keluar dari aplikasi
</p>