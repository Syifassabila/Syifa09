<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tabungan Siswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
  <div class="fullsccreen-image"></div>
</html>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body id="page-top">
<nav class="navbar navbar-expand-lg bg-transparent fixed-top" id="mainNav">
  <div class="container">
    <div class="container">
    <a class="navbar-brand" href="#page-top">Tabungan Siswa</a>

    <button class="navbar-toggler navbar-toggler right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link active js-scroll-trigger" aria-current="page" href="#home">HOME</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="datasiswauser.php">DATA SISWA</a>
        </li>
        <li class="nav-item">
          <a class="nav-link js-scroll-trigger" href="setoranuser.php">DATA SETORAN</a>
        </li>
      </ul>
    </div>
  </div>
</div>
</nav>

<div class="jumbotron">
  <div class="container">
<br>
     <h1 class ="display-4"> Save to achieve your desires</h1>
     <p class="lead"></p>
     <hr class="my-4">
     <p>Rich is not about how much money we earn, but about how well we manage that money</p>
     <a class="btn btn-primary btn-lg font-weight-bold" href="login.php" role="button">login</a>
</div>
</div>

