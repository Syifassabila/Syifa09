<?php
$servername = "localhost";
$database = "tabungan_siswa";
$username = "root";
$password = "";
 
$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("<script>alert('Gagal tersambung dengan database.')</script>");
}
?>