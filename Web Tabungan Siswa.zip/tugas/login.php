<?php
session_start();
include 'koneksi.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LOGIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    
    <link rel="stylesheet" type="text/css" href="login.css">
    
  </head>
  <body>
    
<div class="container" >
    <h4 class="text-center" >Tabungan Siswa</h4>
    <hr>

        <form actio ="" method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Masukan Username Anda">
        </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Masukan Password Anda">
            </div>
<br>
<center>
            <button type="submit" value="Login" name="proseslog" class="btn btn-warning">Simpan</button>

   </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html>
</form>

<?php
if(isset($_POST['proseslog'])){
    $sql =mysqli_query($conn,"select * from login where username ='$_POST[username]' 
    and password = '$_POST[password]'");

    $cek =mysqli_num_rows($sql);
    if($cek > 0){
        $_SESSION['username'] = $_POST['username'];

      echo "<meta http-equiv=refresh content=0;URL='tampilan_admin/dashboard.php'>";
   }else
      echo "<p align=center><b> Username dan Password Salah ! </b></p>";
  }

?>