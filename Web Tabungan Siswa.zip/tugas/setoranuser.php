<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Halo user</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
</head>
  <body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Selamat Datang User | <b>Tabungan</b></a>
    <form class="form-inline my-2 my-lg-0 ml-auto"></form>
      <form class="d-flex ml-auto" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
      </form>

      <div class="icon ml-4">
        <h5>
            <i class="fa-solid fa-envelope mr-3" data-toggle="tooltip" title="Surat Masuk"></i>
            <i class="fa-solid fa-bell mr-3" data-toggle="tooltip" title="Notifikasi"></i>
            <i class="fa-solid fa-right-from-bracket mr-3" data-toggle="tooltip" title="Sign Out"></i>
        </h5>
    </div>
  </div>
</nav>

<br><br>
    
</ul>
</div>
<div class="col-md-10 p-5 pt-2">
  <br>
  <h3><i class="fa-solid fa-pen mr-2"></i> Data Setoran </h3><hr>
  <a href="index.php" class="btn bg-danger text-white mb-3"><i class="fa-solid fa-house  text-white mr-3"></i>  Kembali</a>
  <div class="">
     <div class="col-md">
<table id="example" class="table table-striped table-hover " style="width:100%">
       <thead class="table-dark">
            <tr>
                <th>Id</th>
                <th>Nisn</th>
                <th>Tanggal</th>
                <th>Nominal</th>
                <th></th>
            </tr>
</thead>
		<?php 
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($conn,"select * from data_setoran");
		while($d = mysqli_fetch_array($data)){
			?>
              <tr>
                <td><?php echo $d['id_setoran']; ?></td>
				        <td><?php echo $d['Nisn']; ?></td>
                <td><?php echo $d['Tanggal']; ?></td>
                <td><?php echo $d['Nominal']; ?></td>
                <td>
			</tr>
			<?php 
		}
		?>
	</table>


  </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
 
<script type="text/javascript" src="admin.js"></script>
</body>
</html>