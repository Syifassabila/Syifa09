<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form

$Nisn = $_POST['Nisn'];
$Nama = $_POST['Nama'];
$Kelas = $_POST['Kelas'];
$Alamat = $_POST['Alamat'];
$No_hp = $_POST['No_hp'];
 
// menginput data ke database
mysqli_query($conn, "insert into data_siswa values ('$Nisn','$Nama','$Kelas','$Alamat','$No_hp')");
 
if($proses){
    echo"<script>
    alert('Data gagal di simpan');
    document.location='datasiswa.php';
    </script>";
}else
echo"<script>
alert('Data berhasil di simpan');
document.location='datasiswa.php';
</script>";

?>

