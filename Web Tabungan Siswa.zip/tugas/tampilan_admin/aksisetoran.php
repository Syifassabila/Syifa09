<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id_setoran = $_POST['Id'];
$Nisn = $_POST['Nisn'];
$Tanggal = $_POST['Tanggal'];
$Nominal = $_POST['Nominal'];

 
// menginput data ke database
mysqli_query($conn, "insert into data_setoran values ('$id_setoran','$Nisn','$Tanggal','$Nominal')");
 
if($proses){
    echo"<script>
    alert('Data gagal di simpan');
    document.location='datasetoran.php';
    </script>";
}else
echo"<script>
alert('Data berhasil di simpan');
document.location='datasetoran.php';
</script>";

?>