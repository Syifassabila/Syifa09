<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Tabungan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.min.css">
</head>
  <body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Selamat Datang Admin | <b>Tabungan</b></a>

      <div class="icon ml-4">
        <h5>
            <i class="fa-solid fa-envelope mr-3" data-toggle="tooltip" title="Surat Masuk"></i>
            <i class="fa-solid fa-bell mr-3" data-toggle="tooltip" title="Notifikasi"></i>
            <i class="fa-solid fa-right-from-bracket mr-3" data-toggle="tooltip" title="Sign Out"></i>
            <a href="logout.php">Logout</a>
        </h5>
    </div>
  </div>
</nav>

<div class="row no-gutters mt-5">
<div class="col-md-2 bg-dark mt-2 pr-3 pt-4">
<ul class="nav flex-column ml-3 mb-5">
    <li class="nav-item">
        <a class="nav-link active text-white" href="dashboard.php"><i class="fa-solid fa-gauge mr-2"></i> Dashboard</a><hr class="bg-secondary">
    </li><br>
    <li class="nav-item">
        <a class="nav-link active text-white" href="datasiswa.php"><i class="fa-solid fa-user mr-2"></i> Data Siswa</a><hr class="bg-secondary">
    </li><br>
    <li class="nav-item">
      <a class="nav-link active text-white" href="datasetoran.php"><i class="fa-solid fa-pen mr-2"></i> Data Setoran</a><hr class="bg-secondary">
  </li><br>
 <br>
    
</ul>
</div>
<div class="col-md-10 p-5 pt-2">
  <br>
  <h3><i class="fa-solid fa-gauge mr-2"> Dashboard </i></h3><hr>

<div class="row text-white">
  <div class="card bg-info ml-3" style="width: 18rem;">
    <div class="card-body">
      <div class="card-body-icon">
      <i class="fa-solid fa-user mr-2 text-white"></i>
      </div>
      <h5 class="card-title text-white">TOTAL SISWA</h5>
      <div class="display-4 text-white">24</div>
      <a href="datasiswa.php"><p class="card-text text-white">Lihat Detail <i class="fas fa-angle-double-right ml-2"></i></p></a>
    </div>
  </div>
<br><br>
  <div class="card bg-success ml-3" style="width: 18rem;">
    <div class="card-body">
      <div class="card-body-icon">
      <i class="fa-solid fa-pen mr-2 text-white"></i>
      </div>
      <h5 class="card-title text-white">TOTAL SETORAN</h5>
      <div class="display-4 text-white">20.000</div>
      <a href="datasetoran.php"><p class="card-text text-white">Lihat Detail <i class="fas fa-angle-double-right ml-2"></i></p></a>
    </div>
  </div>

  <div class="card bg-danger ml-3" style="width: 18rem;">
    <div class="card-body">
      <div class="card-body-icon">
      <i class="fa-solid fa-chart-simple mr-2 text-white"></i>
      </div>
      <h5 class="card-title text-white">TOTAL PENARIKAN</h5>
      <div class="display-4 text-white">0</div>
      <a href=""><p class="card-text text-white">Lihat Detail <i class="fas fa-angle-double-right ml-2"></i></p></a>
    </div>
  </div>
</div>

<div class="row mt-4">
  <div class="card ml-5 text-white text-center" style="width: 18rem;">
    <div class="card-header bg-danger display-4 pt-4 pb-4">
      <i class="fa-brands fa-instagram"></i>
    </div>
      <div class="card-body">
         <h5 class="card-title text-danger">Instagram</h5>
         <a href="#" class="btn btn-danger">FOLLOW</a>
        </div>
      </div>

      <div class="card ml-5 text-white text-center" style="width: 18rem;">
        <div class="card-header bg-info display-4 pt-4 pb-4">
          <i class="fa-brands fa-facebook-f"></i>
        </div>
          <div class="card-body">
             <h5 class="card-title text-info">facebook</h5>
             <a href="#" class="btn btn-info text-white">LIKE</a>
            </div>
          </div>

          <div class="card ml-5 text-white text-center" style="width: 18rem;">
            <div class="card-header bg-primary display-4 pt-4 pb-4">
              <i class="fa-brands fa-twitter"></i>
            </div>
              <div class="card-body">
                 <h5 class="card-title text-primary">Twitter</h5>
                 <a href="#" class="btn btn-primary">FOLLOW</a>
                </div>
              </div>

    </div>
  </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
 
<script type="text/javascript" src="admin.js"></script>
</body>
</html>