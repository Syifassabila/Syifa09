<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Tabungan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
</head>
  <body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Selamat Datang Admin | <b>Tabungan</b></a>

      <div class="icon ml-4">
        <h5>
            <i class="fa-solid fa-envelope mr-3" data-toggle="tooltip" title="Surat Masuk"></i>
            <i class="fa-solid fa-bell mr-3" data-toggle="tooltip" title="Notifikasi"></i>
            <i class="fa-solid fa-right-from-bracket mr-3" data-toggle="tooltip" title="Sign Out"></i>
            <a href="logout.php">Logout</a>
        </h5>
    </div>
  </div>
</nav>

<div class="row no-gutters mt-5">
<div class="col-md-2 bg-dark mt-2 pr-3 pt-4">
<ul class="nav flex-column ml-3 mb-5">
    <li class="nav-item">
        <a class="nav-link active text-white" href="dashboard.php"><i class="fa-solid fa-gauge mr-2"></i> Dashboard</a><hr class="bg-secondary">
    </li><br>
    <li class="nav-item">
        <a class="nav-link active text-white" href="datasiswa.php"><i class="fa-solid fa-user mr-2"></i> Data Siswa</a><hr class="bg-secondary">
    </li><br>
    <li class="nav-item">
      <a class="nav-link active text-white" href="datasetoran.php"><i class="fa-solid fa-pen mr-2"></i> Data Setoran</a><hr class="bg-secondary">
  </li><br>
  
</li><br><br><br><br><br><br><br><br>
    
</ul>
</div>
<div class="col-md-10 p-5 pt-2">
  <br>
  <h3><i class="fa-solid fa-pen mr-2"></i> Data Setoran </h3><hr>

  <div class="">
    <!-- Button trigger modal -->
<button type="button" class="btn btn-danger mb-3" data-bs-toggle="modal" data-bs-target="#modaltambah">
  Tambah Data Setoran
</button>
<br>
<form method="post">
      <table>
             <tr>
              <td>Dari</td>
              <td><input type="date" name="dari_tgl" required="required"></td>
              <td>Sampai</td>
              <td><input type="date" name="sampai_tgl" required="required"></td>
              <td><input type="submit" class="btn btn-warning" name="filter" value="filter"></td>
             </tr>
      </table>
</form>
<br>
</div>
<div>
     <div class="col-md">
<table id="example" class="table table-striped table-hover " style="width:100%">
       <thead class="table-dark">
            <tr>
              
                <th>Id</th>
                <th>Nisn</th>
                <th>Tanggal</th>
                <th>Nominal</th>
                <th colspan="2">AKSI</th>
            </tr>
</thead>
		<?php 
		include 'koneksi.php';
		$no = 1;

if(isset($_POST['filter'])){
  $dari_tgl   = mysqli_real_escape_string($conn,$_POST['dari_tgl']);
  $sampai_tgl = mysqli_real_escape_string($conn,$_POST['sampai_tgl']);
  $data       = mysqli_query($conn,"select * from data_setoran where tanggal between '$dari_tgl' and '$sampai_tgl'");
}else{
		$data = mysqli_query($conn,"select * from data_setoran");
}
		while($d = mysqli_fetch_array($data)){
			?>
              <tr>
                
                <td><?php echo $d['id_setoran'] ?></td>
				        <td><?php echo $d['Nisn']; ?></td>
                <td><?php echo $d['Tanggal']; ?></td>
                <td><?php echo $d['Nominal']; ?></td>
                <td>
                <div class="row">
                    <div class="col d-flex justify-content-center">
                      <!-- start modal -->
<button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalubah<?php echo $d['id_setoran']?>">
 Edit
</button>

<form action="" method="POST">
<div class="modal fade" id="modalubah<?php echo $d['id_setoran']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Data</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="mb-3">
  <label  class="form-label">ID</label>
  <input type="text" class="form-control" value="<?php echo $d['id_setoran'];?>" name="id_setoran" placeholder="Masukan ID Siswa!" >
</div>
<div class="mb-3">
  <label  class="form-label">NISN</label>
  <input type="text" class="form-control" value="<?php echo $d['Nisn'];?>" name="Nisn" placeholder="Masukan NISN Siswa!" >
</div>
<div class="mb-3">
  <label  class="form-label">Tanggal</label>
  <input type="date" class="form-control" value="<?php echo $d['Tanggal'];?>" name="Tanggal" placeholder="Masukan Tanggal Siswa!" >
</div>
<div class="mb-3">
  <label  class="form-label">Nominal</label>
  <input type="text" class="form-control" value="<?php echo $d['Nominal'];?>" name="Nominal" placeholder="Masukan Nominal Siswa!" >
</div>
      </div>
      <div class="modal-footer">
      <input type="hidden" name="Nisn" value="<?php echo $d['id_setoran'];?>">
        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal" name="update">Simpan</button>
        <button type="button" class="btn btn-danger">Keluar</button>
      </div>
    </div>
  </div>
</div>
    </form>
   
   <?php
if (isset($_POST['update'])) {
  $id_setoran   =$_POST['id_setoran'];
  $Nisn   =$_POST['Nisn'];
  $Tanggal  =$_POST['Tanggal'];
  $Nominal =$_POST['Nominal'];
  

  $sql ="UPDATE data_setoran SET Nisn='$Nisn',Tanggal='$Tanggal',Nominal='$Nominal' where id_setoran='$id_setoran'";
  
  if ($conn->query($sql) === false) {
    trigger_error("Periksa perintah SQL manual Anda : ". $sql . "Error : " . $conn->error, E_USER_ERROR);
  }else {
    //echo "<meta http-equiv='refresh' content=0.1; url=?page=data-siswa>";
  }
}
?>
<!-- Modal end-->
                      <div class="col d-flex justify-content-center">
                      <a href="deletesetoran.php?hapus=<?php echo $d ['id_setoran']; ?>"  class='btn btn-sm btn-danger' onClick="return confirm('Yakin anda mau hapus data?')">Delete<a>
			</tr>
			<?php 
		}
		?>
	</table>



<!-- Modal -->
<div class="modal fade" id="modaltambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Data Setoran</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" action="aksisetoran.php">
        <div class="modal-body">
      
      <div class="mb-3">
  <label  class="form-label">ID</label>
  <input type="text" class="form-control" name="id_setoran" placeholder="Masukan ID Siswa!" >
</div>
<div class="mb-3">
  <label  class="form-label">NISN</label>
  <input type="text" class="form-control" name="Nisn" placeholder="Masukan NISN Siswa!" >
</div>
<div class="mb-3">
  <label  class="form-label">Tanggal</label>
  <input type="date" class="form-control" name="Tanggal" placeholder="Masukan Tanggal Siswa!" >
</div>
<div class="mb-3">
  <label  class="form-label">Nominal</label>
  <input type="text" class="form-control" name="Nominal" placeholder="Masukan Nominal Siswa!" >
</div>
      </div>
      <div class="modal-footer">
        <button type="sumbit" class="btn btn-primary" name="simpan">Simpan</button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Keluar</button>
      </div>
        </form>
    </div>
  </div>
</div>

  </div>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
 
<script type="text/javascript" src="admin.js"></script>
</body>
</html>