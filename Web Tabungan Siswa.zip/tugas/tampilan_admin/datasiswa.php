
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Tabungan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="admin.css">
  <link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
</head>
  <body>
    
<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Selamat Datang Admin | <b>Tabungan</b></a>


      <div class="icon ml-4">
        <h5>
            <i class="fa-solid fa-envelope mr-3" data-toggle="tooltip" title="Surat Masuk"></i>
            <i class="fa-solid fa-bell mr-3" data-toggle="tooltip" title="Notifikasi"></i>
            <i class="fa-solid fa-right-from-bracket mr-3" data-toggle="tooltip" title="Sign Out"></i>
            <a href="logout.php">Logout</a>
        </h5>
    </div>
  </div>
</nav>

<div class="row no-gutters mt-5">
<div class="col-md-2 bg-dark mt-2 pr-3 pt-4">
<ul class="nav flex-column ml-3 mb-5">
    <li class="nav-item">
        <a class="nav-link active text-white" href="dashboard.php"><i class="fa-solid fa-gauge mr-2"></i> Dashboard</a><hr class="bg-secondary">
    </li><br>
    <li class="nav-item">
        <a class="nav-link active text-white" href="datasiswa.php"><i class="fa-solid fa-user mr-2"></i> Data Siswa</a><hr class="bg-secondary">
    </li><br>
    <li class="nav-item">
      <a class="nav-link active text-white" href="datasetoran.php"><i class="fa-solid fa-pen mr-2"></i> Data Setoran</a><hr class="bg-secondary">
  </li><br>
  
</li><br><br><br><br><br><br><br><br><br><br><br><br>
    
</ul>
</div>
<div class="col-md-10 p-5 pt-2">
  <br>
  <h3><i class="fa-solid fa-user mr-2"></i> Data Siswa </h3><hr>

</form>

  <!-- Button trigger modal -->
<button type="button" class="btn btn-danger mb-3" data-bs-toggle="modal" data-bs-target="#modaltambah">
Tambah data Siswa
</button>

<form method="POST">
    <div class="input-group mb-3">
        <input type="text" name="tcari" class="from-control" placeholder= " Masukan Nama/kelas !">
        <button class="btn btn-warning" name="bcari" type="submit">Cari</button>
        <button class="btn btn-danger" name="breset" type="submit">Reset</button>
    </div>
  </form>

   <div class="">
      <div class="col-md">
<table id="example" class="table table-striped table-hover " style="width:100%">
        <thead class="table-dark">
            <tr>
                <th>Nisn</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Alamat</th>
                <th>No hp</th>
                <th colspan="2">AKSI</th>
            </tr>
        </thead>
        <tbody>
           
                  <?php 
		               include 'koneksi.php';
		                $no = 1;

                   if(isset($_POST['bcari'])){
                    $keyword= $_POST['tcari'];
                    $q ="SELECT * FROM data_siswa where Nama like '%$keyword%' or kelas like '%$keyword%' order by Nisn desc";
                   }else{
                    $q ="SELECT * from data_siswa order by Nisn desc";
                   }

	                	$data = mysqli_query($conn,$q);
		              while($d = mysqli_fetch_array($data)):
		              	?>
		      	<tr>
				
                <td><?php echo $d['Nisn']; ?></td>
                <td><?php echo $d['Nama']; ?></td>
                <td><?php echo $d['Kelas']; ?></td>
                <td><?php echo $d['Alamat']; ?></td>
                <td><?php echo $d['No_hp']; ?></td>
                <td>
                  <div class="row">
                    <div class="col d-flex justify-content-center">

                      <!-- Button Edit Start -->
<button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modaledit<?php echo $d['Nisn']?>">
  Edit
</button>

<form action="" method="POST">
<div class="modal fade" id="modaledit<?php echo $d['Nisn']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit Data</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="mb-3">
     <label  class="form-label">NISN</label>
     <input type="text" class="form-control" value="<?php echo $d['Nisn'];?>" name="Nisn" placeholder="Masukan Nisn Siswa!" >
     </div>
      <div class="mb-3">
     <label  class="form-label">Nama</label>
     <input type="text" class="form-control" value="<?php echo $d['Nama'];?>" name="Nama" placeholder="Masukan Nama Siswa!" >
     </div>
     <div class="mb-3">
     <label  class="form-label">Kelas</label>
     <select class="from-select" name="Kelas">
     <option selected value="<?php echo $d['Kelas'];?>"><?php echo $d['Kelas'];?></option>
     <option>- pilih kelas -</option>
      <option value="Oracle">Oracle</option>
      <option value="PPLG">PPLG</option>
      <option value="ACP">ACP</option>
      <option value="Pemasaran">Pemasaran</option>
      <option value="TKJ">TKJ</option>
      <option value="ATPH">ATPH</option>
                  </select>
     </div>
      <div class="mb-3">
     <label  class="form-label">Alamat</label>
     <input type="text" class="form-control" value="<?php echo $d['Alamat'];?>" name="Alamat" placeholder="Masukan Alamat Siswa!" >
     </div>
      <div class="mb-3">
     <label  class="form-label">No hp</label>
     <input type="text" class="form-control" value="<?php echo $d['No_hp'];?>" name="No_hp" placeholder="Masukan No Hp Siswa!" >
     </div>
      </div>
      <div class="modal-footer">
        <input type="hidden" name="Nisn" value="<?php echo $d['Nisn'];?>">
        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal" name="update">Simpan</button>
        <button type="button" class="btn btn-danger">Keluar</button>
      </div>
    </div>
  </div>
</div>
</form>
<?php
if (isset($_POST['update'])) {
  $Nisn   =$_POST['Nisn'];
  $Nama   =$_POST['Nama'];
  $Kelas  =$_POST['Kelas'];
  $Alamat =$_POST['Alamat'];
  $No_hp  =$_POST['No_hp'];

  $sql ="UPDATE data_siswa SET Nama='$Nama',Kelas='$Kelas',Alamat='$Alamat',No_hp='$No_hp' where Nisn='$Nisn'";
  
  if ($conn->query($sql) === false) {
    trigger_error("Periksa perintah SQL manual Anda : ". $sql . "Error : " . $conn->error, E_USER_ERROR);
  }else {
    //echo "<meta http-equiv='refresh' content=0.1; url=?page=data-siswa>";
  }
}
?>
<!-- Modal edit end -->

                   <div class="col d-flex justify-content-center">
                      <a href="delete.php?hapus=<?php echo $d ['Nisn']; ?>"  class='btn btn-sm btn-danger' onClick="return confirm('Yakin anda mau hapus data?')">Delete<a>
			</tr>
       

			<?php endwhile;?>
              </tbody>
         </table>



<!--Awal Modal -->
<div class="modal fade" id="modaltambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Data Siswa</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
       </div>
      
      <form method="post" action="aksi.php">
      <div class="modal-body">
      
       <div class="mb-3">
     <label  class="form-label">NISN</label>
     <input type="text" class="form-control" name="Nisn" placeholder="Masukan Nisn Siswa!" >
     </div>
      <div class="mb-3">
     <label  class="form-label">Nama</label>
     <input type="text" class="form-control" name="Nama" placeholder="Masukan Nama Siswa!" >
     </div>
     <div class="mb-3">
     <label  class="form-label">Kelas</label>
     <select class="from-select" name="Kelas">
      <option>- pilih kelas -</option>
      <option value="Oracle">Oracle</option>
      <option value="PPLG">PPLG</option>
      <option value="ACP">ACP</option>
      <option value="Pemasaran">Pemasaran</option>
      <option value="TKJ">TKJ</option>
      <option value="ATPH">ATPH</option>
                  </select>
     </div>
      <div class="mb-3">
     <label  class="form-label">Alamat</label>
     <input type="text" class="form-control" name="Alamat" placeholder="Masukan Alamat Siswa!" >
     </div>
      <div class="mb-3">
     <label  class="form-label">No hp</label>
     <input type="text" class="form-control" name="No_hp" placeholder="Masukan No Hp Siswa!" >
     </div>
     </div>
        <div class="modal-footer">
         <button type="sumbit" class="btn btn-primary" name="simpan">Simpan</button>
         <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Keluar</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--Akhir Modal -->

    </div>
</div>

   <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
   <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
   <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
 
<script type="text/javascript" src="admin.js"></script>

<script>
        $(document).ready(function() {
        $('#example').datatatble();
        } );
</script>

</body>
</html>