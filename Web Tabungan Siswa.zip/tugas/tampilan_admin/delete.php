<?php
include 'koneksi.php';

if (isset($_GET['hapus'])) {
    $Nisn = $_GET['hapus'];

    // Hapus data berdasarkan ID
    $sql_delete = "DELETE FROM data_siswa WHERE Nisn = $Nisn";
    if ($conn->query($sql_delete) === TRUE) {
        header("Location: datasiswa.php");
    } else {
        echo "Error: Data gagal dihapus";
    }
} else {
    echo "ID tidak diberikan.";
}
?>