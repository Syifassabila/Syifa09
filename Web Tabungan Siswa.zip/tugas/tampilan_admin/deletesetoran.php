<?php
include 'koneksi.php';

if (isset($_GET['hapus'])) {
    $id_setoran = $_GET['hapus'];

    // Hapus data berdasarkan ID
    $sql_delete = "DELETE FROM data_setoran WHERE id_setoran = $id_setoran";
    if ($conn->query($sql_delete) === TRUE) {
        header("Location: datasetoran.php");
    } else {
        echo "Error: Data gagal dihapus";
    }
} else {
    echo "ID tidak diberikan.";
}
?>