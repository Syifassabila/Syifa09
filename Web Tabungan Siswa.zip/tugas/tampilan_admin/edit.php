<!DOCTYPE html>
<html>
<head>
	<title>Edit Data</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<br/>
	
	<a href="datasiswa.php">Lihat Semua Data</a>
 
	<br/>
	<h3>Edit data</h3>
 
	<?php 
	include "koneksi.php";
	$Nisn = $_GET['Nisn'];
	$query_mysql = mysql_query("SELECT * FROM data_siswa WHERE Nisn='$Nisn'")or die(mysql_error());
	while($data = mysql_fetch_array($query_mysql)){
	?>
	<form action="update.php" method="post">		
		<table>
			<tr>
				<td>Nisn</td>
				<td>
					<input type="hidden" name="Nisn" value="<?php echo $d['Nisn'] ?>">
					<input type="text" name="Nisn" value="<?php echo $d['Nisn'] ?>">
				</td>					
			</tr>	
			<tr>
				<td>Nama</td>
				<td><input type="text" name="Nama" value="<?php echo $d['Nama'] ?>"></td>					
			</tr>	
			<div class="mb-3">
     <label  class="form-label">Kelas</label>
     <select class="from-select" name="Kelas">
      <option></option>
      <option value="Oracle">Oracle</option>
      <option value="PPLG">PPLG</option>
      <option value="ACP">ACP</option>
      <option value="Pemasaran">Pemasaran</option>
      <option value="TKJ">TKJ</option>
      <option value="ATPH">ATPH</option>
                  </select>
     </div>
			<tr>
				<td></td>
				<td><input type="submit" value="Simpan"></td>					
			</tr>				
		</table>
	</form>
	<?php } ?>
</body>
</html>