<?php 
 
include 'koneksi.php';
$Nisn= $_POST['Nisn'];
$Nama = $_POST['Nama'];
$Alamat = $_POST['Alamat'];
$No_hp = $_POST['No_hp'];
 
mysqli_query($koneksi.php,"Nisn='$Nisn',Nama=$Nama ,Alamat='$Alamat',No_hp='$No_hp'");
 
header("location:dashboard.php");
?>

