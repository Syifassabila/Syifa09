<?php
session_start(); 
    if (!isset($_SESSION['level'])){
        header('location:login.php');
    }

    ?>
    Selamat datang <?php $_SESSION['level'];  ?>

    <a href="logout.php">logout</a>